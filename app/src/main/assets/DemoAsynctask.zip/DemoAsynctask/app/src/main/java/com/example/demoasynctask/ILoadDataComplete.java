package com.example.demoasynctask;

import java.util.List;

public interface ILoadDataComplete {
    public void onComplete(List<Item> itemList);
}
